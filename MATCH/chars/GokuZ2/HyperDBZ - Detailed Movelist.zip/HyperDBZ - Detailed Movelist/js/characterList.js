	// Create an object for each character
	// ID should be the folder name in the CHARA folder
	// Having the defaultChara property set to 'yes' will have that character up on intial load
	window.characters = [
							{id: '1general', name: 'General Gameplay Information',  defaultChara: 'yes'},
							{id: 'goku', name: 'Goku'},						
						]